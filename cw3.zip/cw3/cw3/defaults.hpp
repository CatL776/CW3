#ifndef DEFAULTS_HPP_8D896778_BBC2_4D34_B375_E1EC084A36B7
#define DEFAULTS_HPP_8D896778_BBC2_4D34_B375_E1EC084A36B7

#include <chrono>

/* Select default clock
 *
 * The steady clock is a reasonable choice. It is monotonic, meaning that time
 * will never seem to go backwards (this can happen, e.g., during daylight
 * savings switches, or due to adjustments from something like NTP).
 *
 * std::chrono::high_resolution_clock is a reasonable alternative.
 */
using Clock = std::chrono::steady_clock;

/* Alias: time duration in seconds, as a float.
 *
 * Don't use for long durations (e.g., time since application start or
 * similar), as float accuracy decreases quickly.
 */
using Secondsf = std::chrono::duration<float, std::ratio<1>>;

// Configuration
namespace cfg
{
	constexpr char const* kWindowTitle = "COMP3812 - CW3";

	constexpr float kMoveBaseSpeed = 2.4f;
	constexpr float kMoveFastMult = 15.f;
	constexpr float kMoveSlowMult = 0.1f;

	constexpr float kDefaultMouseSensitivity = 0.01f;
}

#endif // DEFAULTS_HPP_8D896778_BBC2_4D34_B375_E1EC084A36B7
