#ifndef CAMERA_HPP_92928E10_BB25_4999_8587_61A4F2811EBA
#define CAMERA_HPP_92928E10_BB25_4999_8587_61A4F2811EBA

#include <vmlib/stdtypes.hpp>

#include "forward.hpp"
#include "defaults.hpp"

class Camera final
{
	public:
		void move( Vec3f ) noexcept;
		void orient( float aMouseDX, float aMouseDY ) noexcept;

		void set_projection( Mat44f const& ) noexcept;
		
		Mat44f world_to_camera() const noexcept;
		Mat44f projection() const noexcept;

		void load_from_file( char const* );
		void save_to_file( char const* ) const;

		void set_mouse_sensitivity( float = cfg::kDefaultMouseSensitivity );

	private:
		Mat44f mWorld2Cam = make_identity<Mat44f>();
		Mat44f mProjection = make_identity<Mat44f>();

		float mSensitivity = cfg::kDefaultMouseSensitivity;
};

#endif // CAMERA_HPP_92928E10_BB25_4999_8587_61A4F2811EBA
