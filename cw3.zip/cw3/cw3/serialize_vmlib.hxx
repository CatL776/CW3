#ifndef SERIALIZE_VMLIB_HXX_5C3E9D78_3BD2_48D6_BDCE_D7956643674B
#define SERIALIZE_VMLIB_HXX_5C3E9D78_3BD2_48D6_BDCE_D7956643674B

// This is a small helper to bridge between Glaze and vmlib.
// Proper reflection in C++ arrives (hopefully) with C++26. Glaze uses a work-
// around to implement reflection in C++23. The specific pattern with a C array
// member in a struct fails here. We can fix this with a specialization for
// Glaze.

#include <span>

#include <glaze/glaze.hpp>
#include <glaze/yaml.hpp>

#include <vmlib/stdtypes.hpp>

// We need to deal with SmallVec<3> with and without the specialization
template< typename tType >
struct glz::meta< SmallVec<3,tType> >
{
	static constexpr auto value = object(
		"x", [](auto&& aSelf) -> auto& { return aSelf[0]; },
		"y", [](auto&& aSelf) -> auto& { return aSelf[1]; },
		"z", [](auto&& aSelf) -> auto& { return aSelf[2]; }
	);
};

// Glaze doesn't quite understand C arrays.
template< std::size_t tN, std::size_t tM, typename tType >
struct glz::meta< SmallMat<tN,tM,tType> >
{
	static constexpr bool custom_write = true; // Enable custom fmt below
	static constexpr auto value = [](auto& aMat) { return std::span{aMat.v}; };
};


// Make matrices a bit more compact by setting flow_style to true for them
template< std::uint32_t tFmt, std::size_t tN, std::size_t tM, typename tType >
struct glz::to< tFmt, SmallMat<tN,tM,tType> >
{
	template< auto tOpts >
	static void op( auto&& aMat, glz::is_context auto&& aCtx, auto&& aBuf, auto& aIt )
	{
		if constexpr (glz::YAML == tFmt)
			glz::serialize<tFmt>::template op< glz::yaml::flow_context_on<tOpts>() >( std::span{aMat.v}, aCtx, aBuf, aIt );
		else
			glz::serialize<tFmt>::template op<tOpts>( std::span{aMat.v}, aCtx, aBuf, aIt );
	}
};

#endif // SERIALIZE_VMLIB_HXX_5C3E9D78_3BD2_48D6_BDCE_D7956643674B
