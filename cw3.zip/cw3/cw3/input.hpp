#ifndef INPUT_HPP_59B4A7FF_CB84_4E1B_9421_53A89B03020E
#define INPUT_HPP_59B4A7FF_CB84_4E1B_9421_53A89B03020E

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "forward.hpp"

enum class EInputAct
{
	forward,
	backward,
	strafeLeft,
	strafeRight,
	levitate,
	sink,
	speedOfSound,
	speedOfSnail,
	max,

	// Aliases...
	holdingShift = speedOfSound,
	holdingCtrl = speedOfSnail
};

struct InputState
{
	float mouseCurX = 0.f, mouseCurY = 0.f;
	float mouseLastX = 0.f, mouseLastY = 0.f;

	bool inputMap[unsigned(EInputAct::max)] = {};
	bool wasMousing = false;
	bool cameraActive = false;
};

void update_from_input( InputState&, Camera&, float aDeltaTSec );

bool process_key( InputState&, int aKey, int aAct, GLFWwindow* );
bool process_motion( InputState&, float aX, float aY, GLFWwindow* );

#endif // INPUT_HPP_59B4A7FF_CB84_4E1B_9421_53A89B03020E
