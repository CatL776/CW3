#ifndef RUNCONFIG_HPP_40E7E2FA_9033_44FC_800B_6EF3F2F9BC97
#define RUNCONFIG_HPP_40E7E2FA_9033_44FC_800B_6EF3F2F9BC97

// IMPORTANT: DO NOT CHANGE THIS FILE WHEN YOU ARE SOLVING COURSEWORK 3!
//
// For CW3, the runconfig.hpp file must remain exactly as it is. In particular,
// you must not change the RuntimeConfig struct.

#include <array>
#include <string>
#include <vector>
#include <optional>

#include <vmlib/stdtypes.hpp>

struct RuntimeConfig
{
	struct Window
	{
		unsigned initialWidth = 1280;
		unsigned initialHeight = 720;
	} window;

	struct Camera
	{
		float fov = 60.f; // in degrees
		float nearDist = 0.1f;
		float farDist = 100.f;
	} camera;

	std::optional<std::string> cameraFile;

	struct Scene
	{
		std::string baseSceneOBJ;

		std::string defaultVertShader;
		std::string defaultFragShader;

		Vec3f sceneAmbient;

		Vec3f sunDirection;
		Vec3f sunColor;


		std::vector<std::string> extraOBJ;

		struct Instance
		{
			std::size_t extraObjectIndex = 0;

			Vec3f position;
			float rotationX = 0.f, rotationY = 0.f, rotationZ = 0.f;
		};
		std::vector<Instance> instances;

		struct Light
		{
			Vec3f position;
			Vec3f color;
		};
		std::vector<Light> lights;

		Instance customModel;

		std::array<std::string,6> skybox;
		std::array<std::string,6> nightbox;
	} scene;

	struct Features
	{
		bool skybox = true; 
		bool reflections = true;
		bool dayNightCycle = true;
		bool customModel = true;
		bool dynamicReflections = true;
		bool waterReflections = true;
	} features;
};

RuntimeConfig load_configuration( int aArgc, char const* const* aArgv );

#endif // RUNCONFIG_HPP_40E7E2FA_9033_44FC_800B_6EF3F2F9BC97
