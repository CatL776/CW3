#include "camera.hpp"

#include <glaze/glaze.hpp>
#include <glaze/yaml.hpp>

#include <support/error.hpp>

#include <vmlib/transform3d.hpp>

#include "serialize_vmlib.hxx"

namespace camera_detail
{
	struct CamData_
	{
		Mat44f world2cam;
		Mat44f projection;
	};
}

void Camera::move( Vec3f aTranslation ) noexcept
{
	mWorld2Cam = make_translation( aTranslation ) * mWorld2Cam;
}
void Camera::orient( float aMouseDX, float aMouseDY ) noexcept
{
	mWorld2Cam = make_rotation_y( aMouseDX * mSensitivity ) * mWorld2Cam;
	mWorld2Cam = make_rotation_x( aMouseDY * mSensitivity ) * mWorld2Cam;
}

void Camera::set_projection( Mat44f const& aProj ) noexcept
{
	mProjection = aProj;
}


Mat44f Camera::world_to_camera() const noexcept
{
	return mWorld2Cam;
}
Mat44f Camera::projection() const noexcept
{
	return mProjection;
}


void Camera::load_from_file( char const* aPath )
{
	std::string buffer;
	if( auto const err = glz::file_to_buffer( buffer, aPath ); bool(err) )
	{
		throw Error( "Unable to load camera data '{}': {}", aPath, glz::format_error(err) );
	}

	camera_detail::CamData_ cd{};
	if( auto const err = glz::read_yaml( cd, buffer ) )
	{
		throw Error( "Error parsing YAML '{}': {}", aPath, glz::format_error(err, buffer) );
	}

	mWorld2Cam = cd.world2cam;
	mProjection = cd.projection;
}
void Camera::save_to_file( char const* aPath ) const
{
	camera_detail::CamData_ cd{};
	cd.world2cam = mWorld2Cam;
	cd.projection = mProjection;
	
	std::string buffer;

	if( auto const err = glz::write_yaml( cd, buffer ) )
	{
		throw Error( "Error writing YAML '{}': {}", aPath, glz::format_error(err, buffer) );
	}

	if( auto const err = glz::buffer_to_file( buffer, aPath ); bool(err) )
	{
		throw Error( "Unable to write camera data '{}': {}", aPath, glz::format_error(err) );
	}
}


void Camera::set_mouse_sensitivity( float aSensitivity )
{
	mSensitivity = aSensitivity;
}
