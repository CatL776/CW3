#include "input.hpp"

#include "defaults.hpp"
#include "camera.hpp"

void update_from_input( InputState& aState, Camera& aCam, float aDeltaT )
{
	auto const& im = aState.inputMap;

	auto const move = aDeltaT * cfg::kMoveBaseSpeed * 
		(im[unsigned(EInputAct::speedOfSound)] ? cfg::kMoveFastMult:1.f) *
		(im[unsigned(EInputAct::speedOfSnail)] ? cfg::kMoveSlowMult:1.f)
	;

	if( im[unsigned(EInputAct::forward)] )
		aCam.move( Vec3f{ 0.f, 0.f, +move } );
	if( im[unsigned(EInputAct::backward)] )
		aCam.move( Vec3f{ 0.f, 0.f, -move } );

	if( im[unsigned(EInputAct::strafeLeft)] )
		aCam.move( Vec3f{ +move, 0.f, 0.f } );
	if( im[unsigned(EInputAct::strafeRight)] )
		aCam.move( Vec3f{ -move, 0.f, 0.f } );

	if( im[unsigned(EInputAct::levitate)] )
		aCam.move( Vec3f{ 0.f, -move, 0.f } );
	if( im[unsigned(EInputAct::sink)] )
		aCam.move( Vec3f{ 0.f, +move, 0.f } );

	if( aState.cameraActive )
	{
		auto const dx = aState.mouseCurX-aState.mouseLastX;
		auto const dy = aState.mouseCurY-aState.mouseLastY;
		aCam.orient( dx, dy );
	}

	aState.mouseLastX = aState.mouseCurX;
	aState.mouseLastY = aState.mouseCurY;
}

bool process_key( InputState& aState, int aKey, int aAct, GLFWwindow* aWindow )
{
	// Space toggles camera
	if( GLFW_KEY_SPACE == aKey && GLFW_PRESS == aAct )
	{
		aState.cameraActive = !aState.cameraActive;

		if( aState.cameraActive )
			glfwSetInputMode( aWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED );
		else
			glfwSetInputMode( aWindow, GLFW_CURSOR, GLFW_CURSOR_NORMAL );

		return true; // Event consumed
	}

	// Camera controls if camera is active
	if( aState.cameraActive )
	{
#		define TUPLE_(x,y) ((std::uint64_t(unsigned(x))<<31)+unsigned(y))
		switch( TUPLE_(aKey,aAct) )
		{
			case TUPLE_(GLFW_KEY_LEFT_SHIFT,GLFW_PRESS): [[fallthrough]];
			case TUPLE_(GLFW_KEY_RIGHT_SHIFT,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::speedOfSound)] = true;
				return true;
			case TUPLE_(GLFW_KEY_LEFT_SHIFT,GLFW_RELEASE): [[fallthrough]];
			case TUPLE_(GLFW_KEY_RIGHT_SHIFT,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::speedOfSound)] = false;
				return true;
			case TUPLE_(GLFW_KEY_LEFT_CONTROL,GLFW_PRESS): [[fallthrough]];
			case TUPLE_(GLFW_KEY_RIGHT_CONTROL,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::speedOfSnail)] = true;
				return true;
			case TUPLE_(GLFW_KEY_LEFT_CONTROL,GLFW_RELEASE): [[fallthrough]];
			case TUPLE_(GLFW_KEY_RIGHT_CONTROL,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::speedOfSnail)] = false;
				return true;

			case TUPLE_(GLFW_KEY_W,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::forward)] = true;
				return true;
			case TUPLE_(GLFW_KEY_W,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::forward)] = false;
				return true;

			case TUPLE_(GLFW_KEY_S,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::backward)] = true;
				return true;
			case TUPLE_(GLFW_KEY_S,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::backward)] = false;
				return true;

			case TUPLE_(GLFW_KEY_A,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::strafeLeft)] = true;
				return true;
			case TUPLE_(GLFW_KEY_A,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::strafeLeft)] = false;
				return true;

			case TUPLE_(GLFW_KEY_D,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::strafeRight)] = true;
				return true;
			case TUPLE_(GLFW_KEY_D,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::strafeRight)] = false;
				return true;

			case TUPLE_(GLFW_KEY_E,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::levitate)] = true;
				return true;
			case TUPLE_(GLFW_KEY_E,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::levitate)] = false;
				return true;

			case TUPLE_(GLFW_KEY_Q,GLFW_PRESS):
				aState.inputMap[unsigned(EInputAct::sink)] = true;
				return true;
			case TUPLE_(GLFW_KEY_Q,GLFW_RELEASE):
				aState.inputMap[unsigned(EInputAct::sink)] = false;
				return true;

			default:
				;
		}
#		undef TUPLE_
	}

	return false; // Event wasn't consumed
}

bool process_motion( InputState& aState, float aX, float aY, GLFWwindow* )
{
	aState.mouseCurX = float(aX);
	aState.mouseCurY = float(aY);
	return aState.cameraActive;
}

