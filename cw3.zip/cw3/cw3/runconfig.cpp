#include "runconfig.hpp"

// IMPORTANT: DO NOT CHANGE THIS FILE WHEN YOU ARE SOLVING COURSEWORK 3!
//
// For CW3, the runconfig.cpp file must remain exactly as it is. In particular,
// you must not change the command line options or how the RuntimeConfig is
// loaded.

#include <print>
#include <string>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <glaze/glaze.hpp>
#include <glaze/yaml.hpp>

#include <support/error.hpp>

#include "serialize_vmlib.hxx"

namespace 
{
	constexpr char const* kDefaultScene_ = "assets/cw3/default.scene";

	RuntimeConfig load_scene_( char const* aPath );
	void synopsis_( char const* );

}

RuntimeConfig load_configuration( int aArgc, char const* const* aArgv )
{
	std::string sceneFile = kDefaultScene_;
	std::string cameraFile;

	unsigned windowWidth = ~0u, windowHeight = ~0u;

	for( int i = 1; i < aArgc; ++i )
	{
		char name[128]{}, value[128]{};
		int ret = std::sscanf( aArgv[i], "--%127[a-zA-Z0-9_]=%127s", name, value );

		if( ret == 1 )
		{
			if( 0 == std::strcmp( "help", name ) )
			{
				synopsis_( aArgv[0] );
				std::exit( 0 );
			}
			else
			{
				throw Error( "Error while parsing command line\n" 
					"Unrecognized flag '--{}'\n"
					"Use --help to print available command line options", name );
			}

		}
		else if( ret == 2 )
		{
			char dummy;
			if( 0 == std::strcmp( "scene", name ) )
			{
				char scene[128]{};
				if( 1 != std::sscanf( value, "%127s", scene ) )
				{
					throw Error( "Error while parsing command line\n" 
						"Value '{}' not valid for --scene\n"
						"Use --help to print available command line options", value );
				}

				sceneFile = scene;
			}
			else if( 0 == std::strcmp( "camera", name ) )
			{
				char camera[128]{};
				if( 1 != std::sscanf( value, "%127s", camera ) )
				{
					throw Error( "Error while parsing command line\n" 
						"Value '{}' not valid for --camera\n"
						"Use --help to print available command line options", value );
				}

				cameraFile = camera;
			}
			else if( 0 == std::strcmp( "geometry", name ) )
			{
				unsigned width = 0, height = 0;
				if( 2 != std::sscanf( value, "%ux%u%c", &width, &height, &dummy ) )
				{
					throw Error( "Error while parsing command line\n" 
						"Value '{}' not valid for --geometry; expected <width>x<height>\n"
						"Use --help to print available command line options", value );
				}

				windowWidth = width;
				windowHeight = height;
			}
			else
			{
				throw Error( "Error while parsing command line\n" 
					"Unrecognized option '--{}' \n"
					"Use --help to print available command line options", name );
			}
		}
		else
		{
			throw Error( "Error while parsing command line\n" 
				"Expected flag, got unparsable mayhem '{}'\n"
				"Use --help to print available command line options", aArgv[i] );
		}
	}

	if( sceneFile.empty() )
		throw Error( "Error: no scene definition" );
	
	auto ret = load_scene_( sceneFile.c_str() );

	if( !cameraFile.empty() )
		ret.cameraFile = cameraFile;

	if( ~0u != windowWidth )
		ret.window.initialWidth = windowWidth;
	if( ~0u != windowHeight )
		ret.window.initialHeight = windowHeight;

	return ret;
}

namespace
{
	RuntimeConfig load_scene_( char const* aPath )
	{
		// Glaze (https://github.com/stephenberry/glaze) gives us some
		// reflection features in C++23 (i.e., before the official C++26). It
		// may not be the fastest to compile, but it does save a lot of tedious
		// typing that (de)serialization normally involves...
		std::string buffer;
		if( auto const err = glz::file_to_buffer( buffer, aPath ); bool(err) )
		{
			throw Error( "Unable to load scene '{}': {}", aPath, glz::format_error(err) );
		}

		RuntimeConfig cfg;
		if( auto const err = glz::read_yaml( cfg, buffer ) )
		{
			throw Error( "Error parsing YAML '{}': {}", aPath, glz::format_error(err, buffer) );
		}
		
		return cfg;
	}
}

namespace
{
	constexpr char const synopsis[] = R"(Synopsis: {0} [--<flag> [...]] [--<option>=<value> [...]]

Where <flag> may be one of the following
  help         : print this help and exit successfully

and where <option> and <value> may be the following
  scene       <path>              load scene definition from <path>
  camera      <path>              use camera specified by <path>
  geometry    <width>x<height>    set initial window size to (width, height)

Values specified on the command line will override values from the scene file.

Example:
  {0} --geometry=1920x1080
Creates a window that is 1920x1080 in size.
)";
	
	void synopsis_( char const* aProgramName )
	{
		std::vprint_unicode( stdout, synopsis, std::make_format_args(aProgramName) );
	}

}
