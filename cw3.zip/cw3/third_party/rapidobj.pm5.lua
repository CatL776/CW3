project( "x-rapidobj" )
	kind "Utility"

	location "."

	files( "rapidobj/include/**.h*" )

	usage "PUBLIC"
		includedirs "rapidobj/include"

project ()

