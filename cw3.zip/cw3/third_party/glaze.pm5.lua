project( "x-glaze" )
	kind "Utility"

	location "."

	files( "glaze/include/**.h*" )

	usage "PUBLIC"
		includedirs "glaze/include"

project ()

