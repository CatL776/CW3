workspace "COMP3812-OpenGL"
	language "C++"
	cppdialect "C++23"

	platforms { "x64" }
	configurations { "debug", "release" }


	startproject "cw3"

	enablepch "Off"
	multiprocessorcompile "On"
	visibility "Hidden"
	vectorextensions "AVX2"

	debugdir "%{wks.location}"
	objdir "_build_/%{cfg.buildcfg}-%{cfg.platform}-%{cfg.toolset}"
	targetsuffix "-%{cfg.buildcfg}-%{cfg.platform}-%{cfg.toolset}"
	
	-- Default toolset options
	filter "toolset:gcc or toolset:clang"
		linkoptions { "-pthread" }
		buildoptions { "-march=native", "-Wall", "-pthread" }

		-- Variable-length arrays (VLAs) are an extension that GCC and clang
		-- have long supported. However, they are not part of the C++ standard.
		-- (MSVC will not compile code with VLAs.)
		buildoptions { "-Werror=vla" }

	filter "toolset:gcc" 
		links { "stdc++exp" }

	filter "toolset:msc-*"
		warnings "extra" -- this enables /W4; default is /W3
		--buildoptions { "/W4" }
		buildoptions { "/utf-8" }
		buildoptions { "/permissive-" }
		defines { "_CRT_SECURE_NO_WARNINGS=1" }
		defines { "_SCL_SECURE_NO_WARNINGS=1" }

		buildoptions {
			"/wd4456", -- declaration of 'foo' hides previous local declaration
		}

	filter "*"

	-- default libraries
	filter "system:linux"
		links "dl"
	
	filter "system:windows"
		links { "OpenGL32", "gdi32", "Shlwapi" }

	filter "*"

	-- default outputs
	filter "kind:StaticLib"
		targetdir "lib/"

	filter "kind:ConsoleApp"
		targetdir "bin/"
		targetextension ".exe"
	
	filter "*"

	--configurations
	filter "debug"
		symbols "On"
		defines { "_DEBUG=1" }

	filter "release"
		optimize "On"
		defines { "NDEBUG=1" }

	filter "*"

-- Third party dependencies
include "third_party" 

-- Projects
project "cw3"
	local sources = { 
		"cw3/**.cpp",
		"cw3/**.hpp",
		"cw3/**.hxx",
		"cw3/**.inl"
	}

	kind "ConsoleApp"
	location "cw3"

	files( sources )

	dependson "cw3-shaders"

	uses "vmlib"
	uses "support"

	uses "x-stb"
	uses "x-glad"
	uses "x-glfw"
	uses "x-glaze"
	uses "x-rapidobj"

project "cw3-shaders"
	local shaders = { 
		"assets/shaders/*.vert",
		"assets/shaders/*.frag",
		"assets/shaders/*.geom",
		"assets/shaders/*.tesc",
		"assets/shaders/*.tese",
		"assets/shaders/*.comp"
	}

	kind "Utility"
	location "assets/shaders"

	files( shaders )

project "support"
	kind "StaticLib"

	location "."
	files {
		"support/**.hpp",
		"support/**.cpp"
	}

	uses "x-glad"
	uses "x-glfw"

	usage "PUBLIC"
		includedirs "support/include"

	usage "INTERFACE"
		links "support"

project "vmlib"
	kind "StaticLib"

	location "."
	files {
		"vmlib/**.cpp",
		"vmlib/**.hpp"
	}

	usage "PUBLIC"
		includedirs "vmlib/include"

	usage "INTERFACE"
		links "vmlib"


--EOF
