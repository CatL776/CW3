#include <support/error.hpp>
#include <support/defaults.hpp>

char const* Error::what() const noexcept
{
#	if !COMP3812_CONF_USE_STACKTRACE
	return mMsg.c_str();
#	else // USE_STACKTRACE
	if( mBuffer.empty() )
		mBuffer = std::format( "{}\n-- from --\n{}--\n", mMsg, mTrace );

	return mBuffer.c_str();
#	endif // ~ USE_STACKTRACE
}


