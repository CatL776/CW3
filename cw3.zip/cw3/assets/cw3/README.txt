Parlahti model (parlahti.{obj,mtl}; L4343A-4k.jpeg)

See coursework brief for details. Elevation data and the orthophoto texture
were obtained from Maanmittauslaitos, the national land survey of Finland. 
The datasets are subject to CC-BY 4.0. It was converted to an OBJ for COMP3812.


Car (car.{obj,mtl})

Car model by the Chalmers Computer Graphics Research Group
http://www.cse.chalmers.se/~uffe/ComputerGraphicsGroup.htm

The car must not be used outside of COMP3812.


Skyboxes (defaultSky*.png and nightSky*.png)

defaultSky: Sunflowers (Pure Sky) by Jarod Guest and Sergej Majboroda
CC0 License
https://polyhaven.com/a/sunflowers_puresky

nightSky: Qwantani Night (Pure Sky) by Greg Zaal and Jarod Guest
CC0 License
https://polyhaven.com/a/qwantani_night_puresky

Skyboxes were converted from HDR spherical maps to SDR cube maps.

