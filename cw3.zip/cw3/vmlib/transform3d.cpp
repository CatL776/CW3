#include <vmlib/transform3d.hpp>

// SOLUTION_TAGS: gl-(ex-[3456]|cw-3)
