#ifndef TRANSFORM3D_HPP_5737C400_DBBB_49FA_B38A_80BC455B1D68
#define TRANSFORM3D_HPP_5737C400_DBBB_49FA_B38A_80BC455B1D68

// SOLUTION_TAGS: gl-(ex-[3456]|cw-3)

#include "stdtypes.hpp"

// Note: for simplicity, we define these only for 4x4 float matrices.

inline
Mat44f make_rotation_x( float aAngle ) noexcept
{
	return {}; // TODO: implement me
}


inline
Mat44f make_rotation_y( float aAngle ) noexcept
{
	return {}; // TODO: implement me
}

inline
Mat44f make_rotation_z( float aAngle ) noexcept
{
	return {}; // TODO: implement me
}

inline
Mat44f make_translation( Vec3f aTranslation ) noexcept
{
	return {}; // TODO: implement me
}
inline
Mat44f make_scaling( float aSX, float aSY, float aSZ ) noexcept
{
	return {}; // TODO: implement me
}

inline
Mat44f make_perspective_projection( float aFovInRadians, float aAspect, float aNear, float aFar ) noexcept
{
	return {}; // TODO: implement me
}

inline
Mat33f mat44_to_mat33( Mat44f const& aM )
{
	return {}; // TODO: implement me
}

#endif // TRANSFORM3D_HPP_5737C400_DBBB_49FA_B38A_80BC455B1D68
